local floor = math.floor
local max = math.max
local min = math.min

local M = {}

local LOG_TAG = "ris.manager"

local SEGMENT_EPSILON = 0.05
local PLAYBACK_EPSILON = 0.05
local CAMERA_RESTORE_INTERVAL = 0.05
local CAMERA_RESTORE_ATTEMPTS = 8

local SETTINGS_FILE = "/settings/RIS_ReplayInstantSystem.json"
local DEFAULT_CAPTURE_DURATION = 30
local VALID_CAPTURE_DURATIONS = {15, 30, 45, 60}
local DEFAULT_SETTINGS = {
  enabled = true,
  captureDuration = DEFAULT_CAPTURE_DURATION,
  notifications = true,
  cameraRestore = true
}

local BUFFER_DIR = "temp/RIS/"
local CURRENT_BUFFER_FILE = BUFFER_DIR .. "current.rpl"
local PREVIOUS_BUFFER_FILE = BUFFER_DIR .. "previous.rpl"
local FINAL_REPLAY_DIR = "replays/"
local FINAL_REPLAY_PREFIX = "RIS_"

local MESSAGE_CATEGORY = "risReplay"
local MESSAGE_ICON = "local_movies"

local MESSAGES = {
  en = {
    saved = "RIS: recent replay saved",
    busy = "RIS: built-in replay is busy",
    empty = "RIS: buffer is not ready yet",
    failed = "RIS: failed to save replay",
    playbackFailed = "RIS: failed to play the latest capture",
    noCaptures = "RIS: no saved captures yet",
    disabled = "RIS: recording is disabled in settings",
    suspended = "RIS: suspended, built-in replay is busy",
    warmup = "RIS: saved %.1f s, buffer is still filling"
  },
  ru = {
    saved = "RIS: сохранены последние 30 секунд",
    busy = "RIS: встроенный реплей сейчас занят",
    empty = "RIS: буфер пока не готов",
    failed = "RIS: не удалось сохранить реплей",
    playbackFailed = "RIS: не удалось воспроизвести последнее сохранение",
    noCaptures = "RIS: пока нет сохранённых реплеев",
    suspended = "RIS: система приостановлена, встроенный реплей занят",
    warmup = "RIS: сохранено %.1f с, буфер ещё заполняется"
  }
}

local state = {
  now = 0,
  sessionActive = false,
  suspended = false,
  waitingForVehicle = false,
  pendingFreshStartAt = nil,
  currentSegment = nil,
  previousSegment = nil,
  playback = nil,
  internalReplayStop = false,
  lastReplayState = "inactive",
  pendingCameraRestore = nil,
  settings = nil
}

local CAMERA_NUMERIC_FIELDS = {
  "camDist",
  "camLastDist",
  "fov",
  "relativeYaw",
  "relativePitch",
  "relYaw",
  "relPitch",
  "seatRotation",
  "mustResetCam",
  "camResetted",
  "cameraResetted"
}

local CAMERA_BOOLEAN_FIELDS = {
  "forwardLooking",
  "lockCamera",
  "configChanged",
  "newtonTranslation",
  "newtonRotation"
}

local CAMERA_VEC3_FIELDS = {
  "camRot",
  "camLastRot",
  "orbitOffset",
  "camBase",
  "camOffset2",
  "camLastTargetPos",
  "camLastTargetPos2",
  "camLastPos",
  "camLastPos2",
  "camLastPosPerp",
  "camVel",
  "preResetPos",
  "targetCenter",
  "targetLeft",
  "targetBack",
  "lastDataPos",
  "lastRefPos",
  "camLastUp",
  "pos",
  "rot",
  "rockPos",
  "seatPosition",
  "velocity",
  "angularVelocity"
}

local function clamp(value, low, high)
  return min(high, max(low, value))
end

local function roundSeconds(seconds)
  return floor((seconds or 0) * 1000 + 0.5) / 1000
end

local function formatSeconds(seconds)
  return string.format("%.1f", max(seconds or 0, 0))
end

local function copyTable(source)
  local result = {}
  for key, value in pairs(source or {}) do
    result[key] = value
  end
  return result
end

local function isValidCaptureDuration(value)
  value = tonumber(value)
  if not value then return false end

  for _, allowedValue in ipairs(VALID_CAPTURE_DURATIONS) do
    if allowedValue == value then
      return true
    end
  end

  return false
end

local function sanitizeSettings(candidate)
  candidate = type(candidate) == "table" and candidate or {}

  return {
    enabled = candidate.enabled ~= false,
    captureDuration = isValidCaptureDuration(candidate.captureDuration) and tonumber(candidate.captureDuration) or DEFAULT_CAPTURE_DURATION,
    notifications = candidate.notifications ~= false,
    cameraRestore = candidate.cameraRestore ~= false
  }
end

local function buildSettingsFromInput(candidate)
  local merged = copyTable(state.settings or DEFAULT_SETTINGS)
  if type(candidate) == "table" then
    for key, value in pairs(candidate) do
      merged[key] = value
    end
  end
  return sanitizeSettings(merged)
end

local function getSettings()
  if not state.settings then
    state.settings = copyTable(DEFAULT_SETTINGS)
  end

  return state.settings
end

local function getCaptureDuration()
  return getSettings().captureDuration or DEFAULT_CAPTURE_DURATION
end

local function isRecordingEnabled()
  return getSettings().enabled ~= false
end

local function areNotificationsEnabled()
  return getSettings().notifications ~= false
end

local function isCameraRestoreEnabled()
  return getSettings().cameraRestore ~= false
end

local function normalizePath(filename)
  if not filename or filename == "" then return nil end
  filename = string.gsub(filename, "\\", "/")
  filename = string.gsub(filename, "^/+", "")
  return filename
end

local function cloneVec3Value(value)
  if not value or value.x == nil or value.y == nil or value.z == nil then return nil end
  return {x = value.x, y = value.y, z = value.z}
end

local function cloneQuatValue(value)
  if not value or value.x == nil or value.y == nil or value.z == nil or value.w == nil then return nil end
  return {x = value.x, y = value.y, z = value.z, w = value.w}
end

local function makeVec3(value)
  if not value then return nil end
  return vec3(value.x, value.y, value.z)
end

local function makeQuat(value)
  if not value then return nil end
  return quat(value.x, value.y, value.z, value.w)
end

local function ensureCoreReplay()
  if not core_replay and extensions and extensions.load then
    extensions.load("core_replay")
  end
  return core_replay ~= nil
end

local function ensureCoreCamera()
  if not core_camera and extensions and extensions.load then
    extensions.load("core_camera")
  end
  return core_camera ~= nil
end

local function getStream()
  if not be then return nil end
  return be:getFileStream()
end

local function getPlayerVehicleId()
  if not be or not be.getPlayerVehicleID then return nil end

  local vid = be:getPlayerVehicleID(0)
  if type(vid) == "number" and vid > 0 then
    return vid
  end

  return nil
end

local function ensureDirectory(path)
  if not FS:directoryExists(path) then
    FS:directoryCreate(path, true)
  end
end

local function removeFileIfExists(filename)
  filename = normalizePath(filename)
  if filename and FS:fileExists(filename) then
    FS:removeFile(filename)
  end
end

local function copyFileIfExists(sourceFile, targetFile)
  sourceFile = normalizePath(sourceFile)
  targetFile = normalizePath(targetFile)
  if not sourceFile or not targetFile or not FS:fileExists(sourceFile) then return false end

  FS:copyFile(sourceFile, targetFile)
  return FS:fileExists(targetFile)
end

local function renameFileIfExists(sourceFile, targetFile)
  sourceFile = normalizePath(sourceFile)
  targetFile = normalizePath(targetFile)
  if not sourceFile or not targetFile or not FS:fileExists(sourceFile) then return false end

  removeFileIfExists(targetFile)

  if FS:renameFile(sourceFile, targetFile) == 0 and FS:fileExists(targetFile) then
    return true
  end

  if copyFileIfExists(sourceFile, targetFile) then
    removeFileIfExists(sourceFile)
    return true
  end

  return false
end

local function showMessage(text, force)
  if not force and not areNotificationsEnabled() then return end
  ui_message(text, 5, MESSAGE_CATEGORY, MESSAGE_ICON)
end

local function getSelectedLanguage()
  if not Lua or not Lua.getSelectedLanguage then return "" end

  local ok, language = pcall(function()
    return Lua:getSelectedLanguage()
  end)

  if ok and type(language) == "string" then
    return string.lower(language)
  end

  return ""
end

local function getMessageLocale()
  local language = getSelectedLanguage()
  if string.find(language, "^ru[_%-]?") then
    return "ru"
  end

  return "en"
end

local function getMessageText(key, ...)
  local locale = getMessageLocale()
  local template = (MESSAGES[locale] and MESSAGES[locale][key]) or MESSAGES.en[key] or ""

  if select("#", ...) > 0 then
    return string.format(template, ...)
  end

  return template
end

local function showWarmupMessage(seconds)
  showMessage(getMessageText("warmup", max(seconds or 0, 0)))
end

local function replayStateName()
  if not core_replay or not core_replay.getState then return "inactive" end
  return core_replay.getState() or "inactive"
end

local function replayLoadedFile()
  if not core_replay or not core_replay.getLoadedFile then return nil end
  return normalizePath(core_replay.getLoadedFile())
end

local function replayPositionSeconds()
  if not core_replay or not core_replay.getPositionSeconds then return 0 end
  return roundSeconds(core_replay.getPositionSeconds() or 0)
end

local function replayTotalSeconds()
  if not core_replay or not core_replay.getTotalSeconds then return 0 end
  return roundSeconds(core_replay.getTotalSeconds() or 0)
end

local function hasPlayerVehicle()
  if getPlayerVehicle then
    return getPlayerVehicle(0) ~= nil
  end

  if be and be.getPlayerVehicleID then
    local vid = be:getPlayerVehicleID(0)
    return type(vid) == "number" and vid > 0
  end

  return false
end

local function currentLevelName()
  if getCurrentLevelIdentifier then
    local identifier = getCurrentLevelIdentifier()
    if identifier and identifier ~= "" then
      return tostring(identifier)
    end
  end

  if core_levels and core_levels.getLevelName and getMissionFilename then
    local missionFilename = getMissionFilename()
    if missionFilename then
      local levelName = core_levels.getLevelName(missionFilename)
      if levelName then
        return tostring(levelName)
      end
    end
  end

  return ""
end

local function buildUiSettingsData()
  local settings = copyTable(getSettings())
  local status = "idle"

  if not settings.enabled then
    status = "disabled"
  elseif state.playback then
    status = "playback"
  elseif state.suspended then
    status = "suspended"
  elseif state.sessionActive and not hasPlayerVehicle() then
    status = "waitingForVehicle"
  elseif state.sessionActive and state.currentSegment and replayStateName() == "recording" then
    status = "recording"
  elseif state.sessionActive then
    status = "armed"
  end

  return {
    locale = getMessageLocale(),
    settings = settings,
    durations = {15, 30, 45, 60},
    status = status,
    hasPlayerVehicle = hasPlayerVehicle(),
    sessionActive = state.sessionActive,
    suspended = state.suspended,
    playbackActive = state.playback ~= nil,
    currentBufferSeconds = roundSeconds(state.currentSegment and state.currentSegment.duration or 0),
    previousBufferSeconds = roundSeconds(state.previousSegment and state.previousSegment.duration or 0)
  }
end

local function notifyUiSettingsChanged()
  guihooks.trigger("RISSettingsChanged", buildUiSettingsData())
end

local function loadSettings()
  state.settings = sanitizeSettings(jsonReadFile(SETTINGS_FILE))
  return copyTable(state.settings)
end

local function saveSettings()
  ensureDirectory("/settings")
  jsonWriteFile(SETTINGS_FILE, getSettings(), true)
end

local function clearBufferFiles()
  ensureDirectory(BUFFER_DIR)
  removeFileIfExists(CURRENT_BUFFER_FILE .. ".rplMeta.json")
  removeFileIfExists(CURRENT_BUFFER_FILE)
  removeFileIfExists(PREVIOUS_BUFFER_FILE .. ".rplMeta.json")
  removeFileIfExists(PREVIOUS_BUFFER_FILE)
end

local function clearBufferState()
  state.currentSegment = nil
  state.previousSegment = nil
end

local function clearPendingCameraRestore()
  state.pendingCameraRestore = nil
end

local function snapshotCameraObject(camera)
  if type(camera) ~= "table" then return nil end

  local snapshot = {}

  for _, fieldName in ipairs(CAMERA_NUMERIC_FIELDS) do
    local value = camera[fieldName]
    if type(value) == "number" then
      snapshot[fieldName] = value
    end
  end

  for _, fieldName in ipairs(CAMERA_BOOLEAN_FIELDS) do
    local value = camera[fieldName]
    if type(value) == "boolean" then
      snapshot[fieldName] = value
    end
  end

  for _, fieldName in ipairs(CAMERA_VEC3_FIELDS) do
    local value = cloneVec3Value(camera[fieldName])
    if value then
      snapshot[fieldName] = value
    end
  end

  if camera.manualzoom and type(camera.manualzoom.fov) == "number" then
    snapshot.manualzoomFov = camera.manualzoom.fov
  end

  return snapshot
end

local function restoreCameraObject(camera, snapshot)
  if type(camera) ~= "table" or type(snapshot) ~= "table" then return end

  for _, fieldName in ipairs(CAMERA_NUMERIC_FIELDS) do
    if snapshot[fieldName] ~= nil then
      camera[fieldName] = snapshot[fieldName]
    end
  end

  for _, fieldName in ipairs(CAMERA_BOOLEAN_FIELDS) do
    if snapshot[fieldName] ~= nil then
      camera[fieldName] = snapshot[fieldName]
    end
  end

  for _, fieldName in ipairs(CAMERA_VEC3_FIELDS) do
    if snapshot[fieldName] ~= nil then
      camera[fieldName] = makeVec3(snapshot[fieldName])
    end
  end

  if snapshot.manualzoomFov and camera.manualzoom then
    camera.manualzoom.fov = snapshot.manualzoomFov
  end
end

local function captureCurrentCameraState()
  if not isCameraRestoreEnabled() then return nil end
  if not ensureCoreCamera() then return nil end

  local snapshot = {
    globalCameraName = core_camera.getActiveGlobalCameraName and core_camera.getActiveGlobalCameraName() or nil,
    playerVehicleId = getPlayerVehicleId()
  }

  if snapshot.globalCameraName == "free" then
    snapshot.position = cloneVec3Value(core_camera.getPosition and core_camera.getPosition() or nil)
    snapshot.rotation = cloneQuatValue(core_camera.getQuat and core_camera.getQuat() or nil)
    snapshot.fov = core_camera.getFovDeg and core_camera.getFovDeg() or nil

    local globalCameras = core_camera.getGlobalCameras and core_camera.getGlobalCameras() or nil
    local freeCamera = globalCameras and globalCameras.free or nil
    snapshot.globalCameraState = snapshotCameraObject(freeCamera)
    return snapshot
  end

  if not snapshot.playerVehicleId or not core_camera.getActiveCamName or not core_camera.getCameraDataById then
    return snapshot.globalCameraName and snapshot or nil
  end

  snapshot.vehicleCameraName = core_camera.getActiveCamName(0)
  if not snapshot.vehicleCameraName or snapshot.vehicleCameraName == "" then
    return snapshot.globalCameraName and snapshot or nil
  end

  local cameraData = core_camera.getCameraDataById(snapshot.playerVehicleId)
  local camera = cameraData and cameraData[snapshot.vehicleCameraName] or nil
  snapshot.vehicleCameraState = snapshotCameraObject(camera)

  return snapshot
end

local function tryRestoreCameraState(snapshot)
  if not snapshot or not ensureCoreCamera() then return false end

  if snapshot.globalCameraName then
    if core_camera.getActiveGlobalCameraName and core_camera.getActiveGlobalCameraName() ~= snapshot.globalCameraName then
      core_camera.setByName(snapshot.globalCameraName, false)
    end

    if snapshot.globalCameraName ~= "free" then
      return true
    end

    local globalCameras = core_camera.getGlobalCameras and core_camera.getGlobalCameras() or nil
    local freeCamera = globalCameras and globalCameras.free or nil
    restoreCameraObject(freeCamera, snapshot.globalCameraState)

    if snapshot.position then
      core_camera.setPosition(0, makeVec3(snapshot.position))
    end
    if snapshot.rotation then
      core_camera.setRotation(0, makeQuat(snapshot.rotation))
    end
    if snapshot.fov then
      core_camera.setFOV(0, snapshot.fov)
    end

    return true
  end

  local playerVehicleId = getPlayerVehicleId()
  if not playerVehicleId or not snapshot.vehicleCameraName or not core_camera.getCameraDataById then
    return false
  end

  if core_camera.getActiveCamName and core_camera.getActiveCamName(0) ~= snapshot.vehicleCameraName then
    core_camera.setByName(0, snapshot.vehicleCameraName, false)
  end

  local cameraData = core_camera.getCameraDataById(playerVehicleId)
  local camera = cameraData and cameraData[snapshot.vehicleCameraName] or nil
  if not camera then return false end

  restoreCameraObject(camera, snapshot.vehicleCameraState)
  return true
end

local function queueCameraRestore(snapshot)
  if not snapshot then return end

  state.pendingCameraRestore = {
    snapshot = snapshot,
    attemptsLeft = CAMERA_RESTORE_ATTEMPTS,
    nextAttemptAt = state.now
  }
end

local function updateCameraRestore()
  local pending = state.pendingCameraRestore
  if not pending then return end
  if not isCameraRestoreEnabled() then
    clearPendingCameraRestore()
    return
  end
  if state.playback then
    clearPendingCameraRestore()
    return
  end
  if pending.attemptsLeft <= 0 then
    clearPendingCameraRestore()
    return
  end
  if state.now < (pending.nextAttemptAt or 0) then
    return
  end

  tryRestoreCameraState(pending.snapshot)

  pending.attemptsLeft = pending.attemptsLeft - 1
  if pending.attemptsLeft <= 0 then
    clearPendingCameraRestore()
  else
    pending.nextAttemptAt = state.now + CAMERA_RESTORE_INTERVAL
  end
end

local function requestFreshStart(delaySeconds)
  state.pendingFreshStartAt = state.now + (delaySeconds or 0)
end

local function cancelFreshStart()
  state.pendingFreshStartAt = nil
end

local function isOwnedRecording(stateName, loadedFile)
  return (stateName or replayStateName()) == "recording" and (loadedFile or replayLoadedFile()) == CURRENT_BUFFER_FILE
end

local function isOwnedPlayback(stateName, loadedFile)
  local playback = state.playback
  if not playback or not playback.currentSegment then return false end
  return (stateName or replayStateName()) == "playback" and (loadedFile or replayLoadedFile()) == playback.currentSegment.file
end

local function isExternalReplayBusy()
  local currentState = replayStateName()
  local loadedFile = replayLoadedFile()

  if currentState == "inactive" then
    return false
  end

  if isOwnedRecording(currentState, loadedFile) or isOwnedPlayback(currentState, loadedFile) then
    return false
  end

  return currentState == "recording" or currentState == "playback"
end

local function stopOwnedRecording()
  if not isOwnedRecording() then return false end

  local stream = getStream()
  if not stream then return false end

  if state.currentSegment then
    state.currentSegment.duration = roundSeconds(max(state.currentSegment.duration or 0, replayPositionSeconds()))
  end

  state.internalReplayStop = true
  stream:stop()
  return true
end

local function teardownBuffer()
  stopOwnedRecording()
  clearPendingCameraRestore()
  clearBufferFiles()
  clearBufferState()
  cancelFreshStart()
end

local function removePreviousSegment()
  state.previousSegment = nil
  removeFileIfExists(PREVIOUS_BUFFER_FILE .. ".rplMeta.json")
  removeFileIfExists(PREVIOUS_BUFFER_FILE)
end

local function promoteCurrentToPrevious(durationSeconds)
  local finalDuration = roundSeconds(durationSeconds or (state.currentSegment and state.currentSegment.duration) or 0)

  removePreviousSegment()

  local moved = renameFileIfExists(CURRENT_BUFFER_FILE, PREVIOUS_BUFFER_FILE)
  renameFileIfExists(CURRENT_BUFFER_FILE .. ".rplMeta.json", PREVIOUS_BUFFER_FILE .. ".rplMeta.json")

  if moved and FS:fileExists(PREVIOUS_BUFFER_FILE) then
    state.previousSegment = {
      file = PREVIOUS_BUFFER_FILE,
      duration = finalDuration
    }
  else
    state.previousSegment = nil
  end

  state.currentSegment = nil
end

local function startCurrentRecording()
  local stream = getStream()
  if not stream then return false end
  if not isRecordingEnabled() then return false end
  if not state.sessionActive or state.suspended or state.playback then return false end
  if not hasPlayerVehicle() then return false end
  if replayStateName() ~= "inactive" then return false end

  ensureDirectory(BUFFER_DIR)
  removeFileIfExists(CURRENT_BUFFER_FILE .. ".rplMeta.json")
  removeFileIfExists(CURRENT_BUFFER_FILE)

  state.currentSegment = {
    file = CURRENT_BUFFER_FILE,
    duration = 0,
    startedAt = state.now
  }

  stream:record(CURRENT_BUFFER_FILE)
  cancelFreshStart()
  log("I", LOG_TAG, "Started buffer recording: " .. CURRENT_BUFFER_FILE)
  return true
end

local function startFreshBuffer()
  if not isRecordingEnabled() then return false end
  if not state.sessionActive or state.suspended or state.playback then return false end
  if not ensureCoreReplay() then return false end
  if not hasPlayerVehicle() then
    requestFreshStart(0.5)
    return false
  end
  if replayStateName() ~= "inactive" then
    requestFreshStart(0.5)
    return false
  end

  clearBufferFiles()
  clearBufferState()
  return startCurrentRecording()
end

local function resetBuffer(delaySeconds)
  teardownBuffer()
  requestFreshStart(delaySeconds or 0.25)
end

local function updateCurrentSegmentDuration()
  if state.currentSegment and isOwnedRecording() then
    state.currentSegment.duration = roundSeconds(max(state.currentSegment.duration or 0, replayPositionSeconds()))
  end
end

local function rotateBufferIfNeeded()
  if not state.currentSegment or not isOwnedRecording() then return end

  local currentDuration = roundSeconds(max(state.currentSegment.duration or 0, replayPositionSeconds()))
  if currentDuration + SEGMENT_EPSILON < getCaptureDuration() then return end

  log("D", LOG_TAG, "Rotating buffer at " .. tostring(currentDuration) .. " s")

  local cameraSnapshot = captureCurrentCameraState()
  stopOwnedRecording()
  promoteCurrentToPrevious(currentDuration)

  if not startCurrentRecording() then
    requestFreshStart(0.25)
  else
    queueCameraRestore(cameraSnapshot)
    updateCameraRestore()
  end
end

local function buildCaptureWindow()
  local currentDuration = 0
  local previousDuration = 0

  if state.currentSegment and state.currentSegment.file and FS:fileExists(state.currentSegment.file) then
    currentDuration = roundSeconds(state.currentSegment.duration or 0)
  end

  if state.previousSegment and state.previousSegment.file and FS:fileExists(state.previousSegment.file) then
    previousDuration = roundSeconds(state.previousSegment.duration or 0)
  end

  local totalAvailable = previousDuration + currentDuration
  local captureDuration = getCaptureDuration()
  local targetDuration = roundSeconds(min(captureDuration, totalAvailable))
  if targetDuration <= 0 then return nil end

  local segments = {}
  local currentPortion = roundSeconds(min(currentDuration, targetDuration))
  local previousPortion = roundSeconds(max(0, targetDuration - currentPortion))

  if previousPortion > 0 and state.previousSegment and state.previousSegment.file and FS:fileExists(state.previousSegment.file) then
    local startSeconds = roundSeconds(max(0, previousDuration - previousPortion))
    local endSeconds = roundSeconds(previousDuration)
    if endSeconds - startSeconds > 0 then
      table.insert(segments, {
        sourceFile = state.previousSegment.file,
        startSeconds = startSeconds,
        endSeconds = endSeconds
      })
    end
  end

  if currentPortion > 0 and state.currentSegment and state.currentSegment.file and FS:fileExists(state.currentSegment.file) then
    local startSeconds = roundSeconds(max(0, currentDuration - currentPortion))
    local endSeconds = roundSeconds(currentDuration)
    if endSeconds - startSeconds > 0 then
      table.insert(segments, {
        sourceFile = state.currentSegment.file,
        startSeconds = startSeconds,
        endSeconds = endSeconds
      })
    end
  end

  if #segments == 0 then return nil end

  local sourceMode = "warmup"
  if targetDuration + SEGMENT_EPSILON >= captureDuration then
    sourceMode = #segments == 1 and "full" or "stitched"
  end

  return {
    createdAt = os.date("%Y-%m-%dT%H:%M:%S"),
    fileStamp = os.date("%Y-%m-%d_%H-%M-%S"),
    level = currentLevelName(),
    totalDuration = targetDuration,
    sourceMode = sourceMode,
    segments = segments
  }
end

local function buildUniqueBaseName(stamp)
  local suffix = 0

  while true do
    local baseName = FINAL_REPLAY_PREFIX .. stamp
    if suffix > 0 then
      baseName = string.format("%s_%02d", baseName, suffix + 1)
    end

    local singleFile = FINAL_REPLAY_DIR .. baseName .. ".rpl"
    local partFile = FINAL_REPLAY_DIR .. baseName .. "_part1.rpl"
    if not FS:fileExists(singleFile) and not FS:fileExists(partFile) then
      return baseName
    end

    suffix = suffix + 1
  end
end

local function buildRisMeta(captureWindow, savedSegments, primaryIndex)
  return {
    primary = primaryIndex == 1,
    primaryFile = savedSegments[1] and savedSegments[1].file or nil,
    version = 2,
    createdAt = captureWindow.createdAt,
    level = captureWindow.level,
    totalDuration = roundSeconds(captureWindow.totalDuration),
    sourceMode = captureWindow.sourceMode,
    segmentIndex = primaryIndex,
    segments = savedSegments
  }
end

local function persistCapture(captureWindow)
  ensureDirectory(FINAL_REPLAY_DIR)

  local baseName = buildUniqueBaseName(captureWindow.fileStamp)
  local savedSegments = {}

  for index, segment in ipairs(captureWindow.segments) do
    local relativeFileName = #captureWindow.segments == 1
      and (baseName .. ".rpl")
      or string.format("%s_part%d.rpl", baseName, index)

    local relativePath = FINAL_REPLAY_DIR .. relativeFileName
    if not copyFileIfExists(segment.sourceFile, relativePath) then
      log("E", LOG_TAG, "Failed to copy replay segment: " .. tostring(segment.sourceFile))
      return nil
    end

    copyFileIfExists(segment.sourceFile .. ".rplMeta.json", relativePath .. ".rplMeta.json")

    table.insert(savedSegments, {
      file = relativeFileName,
      startSeconds = roundSeconds(segment.startSeconds),
      endSeconds = roundSeconds(segment.endSeconds)
    })
  end

  for index, savedSegment in ipairs(savedSegments) do
    local metaPath = FINAL_REPLAY_DIR .. savedSegment.file .. ".rplMeta.json"
    local meta = jsonReadFile(metaPath) or {}
    meta.ris = buildRisMeta(captureWindow, savedSegments, index)
    jsonWriteFile(metaPath, meta, true)
  end

  return {
    baseName = baseName,
    segments = savedSegments,
    createdAt = captureWindow.createdAt,
    totalDuration = roundSeconds(captureWindow.totalDuration),
    sourceMode = captureWindow.sourceMode
  }
end

local function findLatestCapture()
  ensureDirectory(FINAL_REPLAY_DIR)

  local metaFiles = FS:findFiles(FINAL_REPLAY_DIR, "*.rplMeta.json", 0, false, false) or {}
  local newest = nil
  local newestCreatedAt = ""

  for _, metaFile in ipairs(metaFiles) do
    local normalizedMeta = normalizePath(metaFile)
    local meta = normalizedMeta and jsonReadFile(normalizedMeta) or nil
    local ris = meta and meta.ris or nil

    if ris and ris.primary and ris.segments and #ris.segments > 0 then
      local createdAt = tostring(ris.createdAt or "")
      if not newest or createdAt >= newestCreatedAt then
        newest = {
          metaFile = normalizedMeta,
          ris = ris
        }
        newestCreatedAt = createdAt
      end
    end
  end

  if not newest then return nil end

  local resolvedSegments = {}
  for _, segment in ipairs(newest.ris.segments) do
    local filePath = normalizePath(FINAL_REPLAY_DIR .. segment.file)
    if filePath and FS:fileExists(filePath) then
      table.insert(resolvedSegments, {
        file = filePath,
        startSeconds = roundSeconds(segment.startSeconds or 0),
        endSeconds = roundSeconds(segment.endSeconds or 0)
      })
    end
  end

  if #resolvedSegments == 0 then return nil end

  return {
    createdAt = newest.ris.createdAt,
    totalDuration = newest.ris.totalDuration,
    sourceMode = newest.ris.sourceMode,
    segments = resolvedSegments
  }
end

local function finishPlayback()
  if core_replay and core_replay.stop and replayStateName() ~= "inactive" then
    core_replay.stop()
  end

  state.playback = nil
  requestFreshStart(0.25)
  notifyUiSettingsChanged()
end

local function startPlaybackSegment(index)
  local playback = state.playback
  if not playback or not playback.segments[index] then
    finishPlayback()
    return
  end

  playback.index = index
  playback.currentSegment = playback.segments[index]
  playback.loading = true

  core_replay.loadFile(playback.currentSegment.file)
  notifyUiSettingsChanged()
end

local function drivePlayback()
  local playback = state.playback
  if not playback or not playback.currentSegment then return end
  if replayStateName() ~= "playback" then return end
  if replayLoadedFile() ~= playback.currentSegment.file then return end

  local totalSeconds = replayTotalSeconds()
  if totalSeconds <= 0 then return end

  local targetStart = clamp(playback.currentSegment.startSeconds, 0, totalSeconds)
  local targetEnd = clamp(playback.currentSegment.endSeconds, 0, totalSeconds)

  if playback.loading then
    core_replay.seek(clamp(targetStart / max(totalSeconds, 0.001), 0, 1))
    core_replay.pause(false)
    playback.loading = false
    return
  end

  if replayPositionSeconds() + PLAYBACK_EPSILON >= targetEnd then
    if playback.index < #playback.segments then
      startPlaybackSegment(playback.index + 1)
    else
      finishPlayback()
    end
  end
end

local function suspendForExternalReplay()
  if state.suspended then return end

  log("I", LOG_TAG, "Suspending because built-in replay is busy")
  state.suspended = true
  teardownBuffer()
  showMessage(getMessageText("suspended"))
  notifyUiSettingsChanged()
end

local function resumeAfterExternalReplay()
  if not state.suspended then return end

  state.suspended = false
  requestFreshStart(0.25)
  notifyUiSettingsChanged()
end

local function saveLast30Seconds()
  if not ensureCoreReplay() then
    showMessage(getMessageText("failed"))
    return
  end

  if not isRecordingEnabled() then
    showMessage(getMessageText("disabled"), true)
    return
  end

  if state.suspended or state.playback or isExternalReplayBusy() then
    showMessage(getMessageText("busy"))
    return
  end

  local hadCurrentSegment = state.currentSegment and state.currentSegment.file and FS:fileExists(state.currentSegment.file)
  local cameraSnapshot = hadCurrentSegment and captureCurrentCameraState() or nil

  if isOwnedRecording() then
    state.currentSegment.duration = roundSeconds(max(state.currentSegment.duration or 0, replayPositionSeconds()))
    stopOwnedRecording()
  elseif state.currentSegment then
    state.currentSegment.duration = roundSeconds(state.currentSegment.duration or 0)
  end

  local captureWindow = buildCaptureWindow()
  if not captureWindow then
    if hadCurrentSegment then
      promoteCurrentToPrevious(state.currentSegment and state.currentSegment.duration or 0)
      if not startCurrentRecording() then
        requestFreshStart(0.25)
      else
        queueCameraRestore(cameraSnapshot)
        updateCameraRestore()
      end
    end
    showMessage(getMessageText("empty"))
    notifyUiSettingsChanged()
    return
  end

  local captureInfo = persistCapture(captureWindow)
  if not captureInfo then
    if hadCurrentSegment then
      promoteCurrentToPrevious(state.currentSegment and state.currentSegment.duration or 0)
      if not startCurrentRecording() then
        requestFreshStart(0.25)
      else
        queueCameraRestore(cameraSnapshot)
        updateCameraRestore()
      end
    end
    showMessage(getMessageText("failed"))
    notifyUiSettingsChanged()
    return
  end

  if captureWindow.sourceMode == "warmup" then
    showWarmupMessage(captureInfo.totalDuration)
  else
    showMessage(getMessageText("saved"))
  end

  if hadCurrentSegment then
    promoteCurrentToPrevious(state.currentSegment and state.currentSegment.duration or 0)
  end

  if not startCurrentRecording() then
    requestFreshStart(0.25)
  else
    queueCameraRestore(cameraSnapshot)
    updateCameraRestore()
  end

  notifyUiSettingsChanged()
end

local function playLatestCapture()
  if not ensureCoreReplay() then
    showMessage(getMessageText("playbackFailed"))
    return
  end

  if state.playback or state.suspended or (isExternalReplayBusy() and not isOwnedRecording()) then
    showMessage(getMessageText("busy"))
    return
  end

  local latestCapture = findLatestCapture()
  if not latestCapture then
    showMessage(getMessageText("noCaptures"))
    return
  end

  teardownBuffer()

  state.playback = {
    index = 0,
    currentSegment = nil,
    loading = false,
    segments = latestCapture.segments
  }

  startPlaybackSegment(1)
  notifyUiSettingsChanged()
end

local function applyUiSettings(newSettings)
  local previousSettings = copyTable(getSettings())
  local updatedSettings = buildSettingsFromInput(newSettings)

  state.settings = updatedSettings
  saveSettings()

  if not isCameraRestoreEnabled() then
    clearPendingCameraRestore()
  end

  if state.sessionActive and not state.playback and not state.suspended then
    if previousSettings.enabled ~= updatedSettings.enabled then
      if updatedSettings.enabled then
        requestFreshStart(0)
      else
        teardownBuffer()
      end
    elseif previousSettings.captureDuration ~= updatedSettings.captureDuration and updatedSettings.enabled then
      resetBuffer(0.1)
    end
  elseif not updatedSettings.enabled then
    clearPendingCameraRestore()
  end

  notifyUiSettingsChanged()
  return buildUiSettingsData()
end

local function resetUiSettings()
  return applyUiSettings(copyTable(DEFAULT_SETTINGS))
end

local function requestUiSettings()
  local data = buildUiSettingsData()
  guihooks.trigger("RISSettingsChanged", data)
  return data
end

local function onInit()
  setExtensionUnloadMode(M, "manual")
  ensureCoreReplay()
  loadSettings()
  ensureDirectory(BUFFER_DIR)
  ensureDirectory(FINAL_REPLAY_DIR)
  clearBufferFiles()
  clearBufferState()
  state.lastReplayState = replayStateName()
  notifyUiSettingsChanged()
end

local function startSession()
  state.sessionActive = true
  state.suspended = false
  state.waitingForVehicle = false
  state.playback = nil
  state.internalReplayStop = false
  clearPendingCameraRestore()
  clearBufferFiles()
  clearBufferState()
  if isRecordingEnabled() then
    requestFreshStart(0)
  else
    cancelFreshStart()
  end
  notifyUiSettingsChanged()
end

local function stopSession()
  state.sessionActive = false
  state.suspended = false
  state.waitingForVehicle = false
  if state.playback and core_replay and core_replay.stop and replayStateName() == "playback" then
    core_replay.stop()
  end
  state.playback = nil
  state.internalReplayStop = false
  clearPendingCameraRestore()
  teardownBuffer()
  notifyUiSettingsChanged()
end

local function onUpdate(dtReal)
  state.now = state.now + (dtReal or 0)
  updateCameraRestore()

  if state.playback then
    drivePlayback()
    return
  end

  if not state.sessionActive or state.suspended or not isRecordingEnabled() then return end

  if not hasPlayerVehicle() then
    if not state.waitingForVehicle then
      state.waitingForVehicle = true
      resetBuffer(0.5)
    end
    return
  end

  if state.waitingForVehicle then
    state.waitingForVehicle = false
    requestFreshStart(0.1)
  end

  if state.pendingFreshStartAt and state.now >= state.pendingFreshStartAt then
    if not startFreshBuffer() then
      requestFreshStart(0.5)
    end
  end

  updateCurrentSegmentDuration()
  rotateBufferIfNeeded()
end

local function onReplayStateChanged(newState)
  local replayState = newState and newState.state or replayStateName()
  local loadedFile = normalizePath(newState and newState.loadedFile or replayLoadedFile())
  local previousState = state.lastReplayState

  state.lastReplayState = replayState or "inactive"

  if isOwnedRecording(replayState, loadedFile) or isOwnedPlayback(replayState, loadedFile) then
    state.internalReplayStop = false
    return
  end

  if replayState == "recording" or replayState == "playback" then
    suspendForExternalReplay()
    return
  end

  if replayState == "inactive" then
    if state.playback and previousState == "playback" then
      if state.playback.loading then
        state.internalReplayStop = false
        return
      end
      if state.playback.index < #state.playback.segments then
        startPlaybackSegment(state.playback.index + 1)
      else
        finishPlayback()
      end
      state.internalReplayStop = false
      return
    end

    if state.suspended then
      resumeAfterExternalReplay()
      state.internalReplayStop = false
      return
    end

    if previousState == "recording" and not state.internalReplayStop and state.sessionActive then
      requestFreshStart(0.5)
    end
  end

  state.internalReplayStop = false
end

local function onClientStartMission()
  startSession()
end

local function onClientEndMission()
  stopSession()
end

local function onVehicleSwitched()
  if not state.sessionActive or state.suspended or state.playback then return end
  resetBuffer(0.25)
end

local function trackVehReset()
  if not state.sessionActive or state.suspended or state.playback then return end
  resetBuffer(0.25)
end

local function onExtensionUnloaded()
  stopSession()
end

M.onInit = onInit
M.onUpdate = onUpdate
M.onReplayStateChanged = onReplayStateChanged
M.onClientStartMission = onClientStartMission
M.onClientEndMission = onClientEndMission
M.onVehicleSwitched = onVehicleSwitched
M.trackVehReset = trackVehReset
M.onExtensionUnloaded = onExtensionUnloaded

M.saveLast30Seconds = saveLast30Seconds
M.playLatestCapture = playLatestCapture
M.requestUiSettings = requestUiSettings
M.applyUiSettings = applyUiSettings
M.resetUiSettings = resetUiSettings

return M
