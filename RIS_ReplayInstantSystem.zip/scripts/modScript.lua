extensions.load("ris_manager")

if not core_input_actions then
  extensions.load("core_input_actions")
end

if not core_input_bindings then
  extensions.load("core_input_bindings")
end

if extensions.core_input_actions and extensions.core_input_actions.onFileChanged then
  extensions.core_input_actions.onFileChanged("/lua/ge/extensions/core/input/actions/risReplay.json")
end

if extensions.core_input_bindings and extensions.core_input_bindings.onFirstUpdate then
  extensions.core_input_bindings.onFirstUpdate()
end
