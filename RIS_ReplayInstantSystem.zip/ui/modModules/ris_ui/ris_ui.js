angular.module("ris_ui", [])

.config(["$stateProvider", function ($stateProvider) {
  $stateProvider.state("menu.ris", {
    url: "/ris/:mode",
    params: {
      mode: null,
    },
    templateUrl: "/ui/modModules/ris_ui/ris.html",
    controller: "RISSettingsController as ris",
    backState: "BACK_TO_MENU",
  })
}])

.run(["$rootScope", "$timeout", function ($rootScope, $timeout) {
  var locale = "en"

  var TEXTS = {
    en: {
      menuButton: "RIS Settings",
    },
    ru: {
      menuButton: "Настройки RIS",
    },
  }

  function normalizeLocale(value) {
    return typeof value === "string" && value.indexOf("ru") === 0 ? "ru" : "en"
  }

  function t(key) {
    return (TEXTS[locale] && TEXTS[locale][key]) || TEXTS.en[key] || key
  }

  function addMainMenuButton(addButton) {
    if (typeof addButton !== "function") return

    addButton({
      title: t("menuButton"),
      iconId: "movieCamera",
      action: "menu.ris",
    })
  }

  function refreshMenuButtonTitle(done) {
    bngApi.engineLua("extensions.ris_manager.requestUiSettings()", function (data) {
      locale = normalizeLocale(data && data.locale)
      if (typeof done === "function") {
        done()
      }
    })
  }

  function broadcastButtonRefresh() {
    if (window.bridge && window.bridge.events) {
      window.bridge.events.emit("BroadcastMainMenuButtons")
    }
  }

  $rootScope.$on("MainMenuButtons", function (event, addButton) {
    addMainMenuButton(addButton)
  })

  $timeout(function () {
    refreshMenuButtonTitle(function () {
      broadcastButtonRefresh()
      $timeout(broadcastButtonRefresh, 500)
    })
  }, 0)
}])

.controller("RISSettingsController", ["$scope", "$state", "$timeout", function ($scope, $state, $timeout) {
  var vm = this

  vm.loading = true
  vm.locale = "en"
  vm.durationOptions = [15, 30, 45, 60]
  vm.data = {
    enabled: true,
    captureDuration: 30,
    notifications: true,
    cameraRestore: true,
  }
  vm.runtime = {
    status: "idle",
    currentBufferSeconds: 0,
    previousBufferSeconds: 0,
  }

  var TEXTS = {
    en: {
      pageKicker: "Replay Instant System",
      pageTitle: "RIS Settings",
      pageDescription: "Tune how RIS records the recent replay window and how it behaves while you drive.",
      captureTitle: "Capture",
      captureDescription: "Background replay recording that can be saved instantly with your hotkey.",
      enabledTitle: "Enable background recording",
      enabledDescription: "When disabled, RIS stops keeping the rolling replay buffer in memory.",
      durationTitle: "Replay window length",
      durationDescription: "How many recent seconds RIS keeps ready for instant saving.",
      behaviorTitle: "Behavior",
      behaviorDescription: "Small quality-of-life options for notifications and camera handling.",
      notificationsTitle: "Show RIS notifications",
      notificationsDescription: "Display save, warmup, conflict, and playback messages on screen.",
      cameraRestoreTitle: "Restore camera on segment switch",
      cameraRestoreDescription: "Keeps your current camera mode when RIS rotates its internal replay parts.",
      toolsTitle: "Tools",
      toolsDescription: "Quick actions for testing the mod and opening saved captures.",
      statusTitle: "Current status",
      bufferNow: "Current part",
      bufferPrev: "Previous part",
      secondsSuffix: "s",
      statusDisabled: "Disabled",
      statusPlayback: "Playing saved capture",
      statusSuspended: "Paused because built-in replay is busy",
      statusWaitingForVehicle: "Waiting for the player vehicle",
      statusRecording: "Recording",
      statusArmed: "Armed and ready",
      statusIdle: "Idle",
      saveNow: "Save Replay Now",
      openFolder: "Open Replays Folder",
      resetDefaults: "Reset Defaults",
      close: "Back to Menu",
    },
    ru: {
      pageKicker: "Replay Instant System",
      pageTitle: "Настройки RIS",
      pageDescription: "Настрой, как RIS держит быстрый реплей в фоне и как он ведет себя во время езды.",
      captureTitle: "Запись",
      captureDescription: "Фоновый буфер реплея, который можно мгновенно сохранить горячей клавишей.",
      enabledTitle: "Включить фоновую запись",
      enabledDescription: "Если выключить, RIS перестанет держать rolling buffer последних секунд.",
      durationTitle: "Длина окна реплея",
      durationDescription: "Сколько последних секунд RIS держит готовыми для мгновенного сохранения.",
      behaviorTitle: "Поведение",
      behaviorDescription: "Небольшие настройки уведомлений и поведения камеры.",
      notificationsTitle: "Показывать уведомления RIS",
      notificationsDescription: "Показывать сообщения о сохранении, прогреве буфера, конфликтах и воспроизведении.",
      cameraRestoreTitle: "Восстанавливать камеру при смене части",
      cameraRestoreDescription: "Ставит назад текущий режим камеры, когда RIS ротирует внутренние части реплея.",
      toolsTitle: "Инструменты",
      toolsDescription: "Быстрые действия для проверки мода и открытия сохраненных реплеев.",
      statusTitle: "Текущее состояние",
      bufferNow: "Текущая часть",
      bufferPrev: "Предыдущая часть",
      secondsSuffix: "с",
      statusDisabled: "Выключен",
      statusPlayback: "Воспроизводит сохраненный реплей",
      statusSuspended: "Пауза: встроенный реплей сейчас занят",
      statusWaitingForVehicle: "Ожидание машины игрока",
      statusRecording: "Идет запись",
      statusArmed: "Готов к работе",
      statusIdle: "Ожидание",
      saveNow: "Сохранить Реплей Сейчас",
      openFolder: "Открыть Папку Реплеев",
      resetDefaults: "Сбросить По Умолчанию",
      close: "Назад в Меню",
    },
  }

  function normalizeLocale(value) {
    return typeof value === "string" && value.indexOf("ru") === 0 ? "ru" : "en"
  }

  function applyData(data) {
    if (!data) return

    vm.loading = false
    vm.locale = normalizeLocale(data.locale)
    vm.durationOptions = Array.isArray(data.durations) && data.durations.length ? data.durations : [15, 30, 45, 60]
    vm.data = angular.extend({}, vm.data, data.settings || {})
    vm.runtime = angular.extend({}, vm.runtime, {
      status: data.status || "idle",
      currentBufferSeconds: data.currentBufferSeconds || 0,
      previousBufferSeconds: data.previousBufferSeconds || 0,
    })
  }

  vm.t = function (key) {
    return (TEXTS[vm.locale] && TEXTS[vm.locale][key]) || TEXTS.en[key] || key
  }

  vm.durationText = function (value) {
    return value + " " + vm.t("secondsSuffix")
  }

  vm.statusText = function () {
    var statusKey = "status" + (vm.runtime.status ? vm.runtime.status.charAt(0).toUpperCase() + vm.runtime.status.slice(1) : "Idle")
    return vm.t(statusKey)
  }

  vm.request = function () {
    bngApi.engineLua("extensions.ris_manager.requestUiSettings()", function (data) {
      $scope.$evalAsync(function () {
        applyData(data)
      })
    })
  }

  vm.apply = function () {
    var payload = {
      enabled: !!vm.data.enabled,
      captureDuration: Number(vm.data.captureDuration) || 30,
      notifications: !!vm.data.notifications,
      cameraRestore: !!vm.data.cameraRestore,
    }

    bngApi.engineLua("extensions.ris_manager.applyUiSettings(" + bngApi.serializeToLua(payload) + ")", function (data) {
      $scope.$evalAsync(function () {
        applyData(data)
      })
    })
  }

  vm.reset = function () {
    bngApi.engineLua("extensions.ris_manager.resetUiSettings()", function (data) {
      $scope.$evalAsync(function () {
        applyData(data)
      })
    })
  }

  vm.saveNow = function () {
    bngApi.engineLua("extensions.ris_manager.saveLast30Seconds()")
    $timeout(vm.request, 150)
  }

  vm.openReplayFolder = function () {
    bngApi.engineLua("core_replay.openReplayFolderInExplorer()")
  }

  vm.close = function () {
    var targetState = $state.params && $state.params.mode === "mainMenuOthers"
      ? "menu.mainmenu.others"
      : "menu.mainmenu"

    if (window.bngVue && window.bngVue.gotoGameState) {
      window.bngVue.gotoGameState(targetState, { tryAngularJS: true, blankAngularJS: true })
      return
    }

    $state.go("menu.mainmenu")
  }

  $scope.$on("RISSettingsChanged", function (event, data) {
    $scope.$evalAsync(function () {
      applyData(data)
    })
  })

  vm.request()
}])

export default true
